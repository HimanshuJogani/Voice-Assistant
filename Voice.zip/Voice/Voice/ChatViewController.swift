//
//  ChatViewController.swift
//  Voice
//
//  Created by Himanshu on 21/02/21.
//

import UIKit
import MessageKit
import Foundation

struct Sender: SenderType {
    var senderId: String
    
    var displayName: String
    
}

struct Message: MessageType {
    var sender: SenderType
    var messageId: String
    var sentDate: Date
    var kind: MessageKind
}


class ChatViewController: MessagesViewController, MessagesDataSource, MessagesLayoutDelegate, MessagesDisplayDelegate {
    
    let currentUser = Sender(senderId: "self", displayName: "IOS Academy")
    
    let otherUser = Sender(senderId: "other", displayName: "IOS")
    
    var message = [MessageType]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesLayoutDelegate = self
        messagesCollectionView.messagesDisplayDelegate = self
        


        // Do any additional setup after loading the view.
        
        message.append(Message(sender: currentUser, messageId: "1", sentDate: Date().addingTimeInterval(-86400), kind: .text("Hello World")))

        message.append(Message(sender: otherUser, messageId: "2", sentDate: Date().addingTimeInterval(-7000), kind: .text("Hello World")))

        message.append(Message(sender: currentUser, messageId: "3", sentDate: Date().addingTimeInterval(-66400), kind: .text("Hello World")))

        message.append(Message(sender: otherUser, messageId: "4", sentDate: Date().addingTimeInterval(-56400), kind: .text("Hello World")))

        message.append(Message(sender: currentUser, messageId: "5", sentDate: Date().addingTimeInterval(-46400), kind: .text("Hello World")))

        message.append(Message(sender: otherUser, messageId: "6", sentDate: Date().addingTimeInterval(-36400), kind: .text("Hello World")))
    }
    

    func currentSender() -> SenderType {
        return currentUser
    }
    
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType {
        return message[indexPath.section]
    }
    
    func numberOfSections(in messagesCollectionView: MessagesCollectionView) -> Int {
        return message.count
    }
   

}



