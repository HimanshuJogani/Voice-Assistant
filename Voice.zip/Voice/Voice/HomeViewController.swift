//
//  HomeViewController.swift
//  Voice
//
//  Created by Himanshu on 20/03/21.
//

import UIKit

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   

}
