//
//  ChatModel.swift
//  Voice
//
//  Created by Himanshu on 22/02/21.
//

import Foundation

struct Chat : Codable {
    let msg : String?

    enum CodingKeys: String, CodingKey {

        case msg = "msg"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        msg = try values.decodeIfPresent(String.self, forKey: .msg)
    }

}
