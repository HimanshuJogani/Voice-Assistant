//
//  ChatViewModel.swift
//  Voice
//
//  Created by Himanshu on 22/02/21.
//

import Foundation
import UIKit


  
class ChatRoom {
    
    var data = [Chat]()
    
    
    func getAllUserData() {
        URLSession.shared.dataTask(with: URL(string: "http://azdhebaryt.pythonanywhere.com/api/v1/users?msg=%22hello%22")!) { (data, response, error) in
            if error == nil {
                if let data = data {
                do {
                    let userResponse = try JSONDecoder().decode([Chat].self, from: data)
                    print(userResponse)
                    self.data.append(contentsOf: userResponse)
                    print(data)
                    DispatchQueue.main.async {
                       // self.vc?.tblView.reloadData()
                    }
                   
                } catch let err{
                    print(err.localizedDescription)
                }
             }
            } else {
                print(error!.localizedDescription)
            }
        }.resume()
    }
}
